package edu.spring.ex10.persistence;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.spring.ex10.domain.ProductVO;


@Repository
public class ProductDAOImple implements ProductDAO {
	
	private static final Logger logger =
			LoggerFactory.getLogger(ProductDAOImple.class);
	private static final String NAMESPACE= 
			"edu.spring.ex10.ProductMapper";
	
	@Autowired
	private SqlSession sqlSession;



	@Override
	public List<ProductVO> listProduct() {
		// TODO Auto-generated method stub
		
		logger.info("--------listProduct()ȣ��--------");
		return sqlSession.selectList(NAMESPACE+ ".listProduct");
	}

	@Override
	public ProductVO detailProduct(int productId) {
		logger.info("--------detailProduct()ȣ��--------"); 
		return sqlSession.selectOne(NAMESPACE + ".detailProduct", productId);
	}




}
