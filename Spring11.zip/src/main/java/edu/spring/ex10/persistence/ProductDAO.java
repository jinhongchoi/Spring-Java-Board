package edu.spring.ex10.persistence;

import java.util.List;

import edu.spring.ex10.domain.ProductVO;


public interface ProductDAO {
	
	
	List<ProductVO>listProduct();
	
	ProductVO detailProduct(int productId);
	
	
}
