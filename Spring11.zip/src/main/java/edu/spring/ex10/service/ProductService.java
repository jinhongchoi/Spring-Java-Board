package edu.spring.ex10.service;

import java.util.List;

import edu.spring.ex10.domain.ProductVO;


// CRUD(Create, Read, Update, Delete)
public interface ProductService {
		

	
	List<ProductVO>listProduct();
	
	ProductVO detailProduct(int productId);
	

	
}
